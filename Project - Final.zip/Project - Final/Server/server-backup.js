const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();
const port = 3000;

//Set up MySQL connection
const db = mysql.createConnection({
    host: 'localhost',  
    user: 'root',        
    password: 'root2',   
    database: 'financial_planner', 
    port: 3306       //The port used in the MySQL database
});

//Test MySQL connection
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        process.exit(1);
    } else {
        console.log('Successfully connected to MySQL database');
    }
});

app.use(cors());

app.use(express.json());

//POST route for submitting expenses
app.post('/submit-expenses', (req, res) => {
    const { user_id, expenses } = req.body;

    if (!user_id || !expenses || !Array.isArray(expenses)) {
        return res.status(400).json({ error: 'Invalid request data' });
    }

    const query = 'INSERT INTO expenses (user_id, amount, category, date_spent, description) VALUES ?';
    const values = expenses.map(expense => [
        user_id,
        expense.amount,
        expense.category,
        expense.date,
        expense.description,
    ]);

    console.log('Query Values:', values);

    //Insert expenses into the database
    db.query(query, [values], (err, result) => {
        if (err) {
            console.error('Error inserting expenses into MySQL:', err);
            return res.status(500).json({ error: 'Failed to insert expenses into database' });
        }

        console.log('Query Result:', result);

        res.status(200).json({ message: 'Expenses submitted successfully!' });
    });
});

//POST route for submitting incomes
app.post('/submit-incomes', (req, res) => {
    const { user_id, incomes } = req.body;

    if (!user_id || !incomes || !Array.isArray(incomes)) {
        return res.status(400).json({ error: 'Invalid request data' });
    }

    const query = 'INSERT INTO Incomes (user_id, amount, source, date_received, description) VALUES ?';
    const values = incomes.map(income => [
        user_id,
        income.amount,
        income.source,
        income.date,
        income.description,
    ]);

    console.log('Query Values:', values);

    //Insert incomes into the database
    db.query(query, [values], (err, result) => {
        if (err) {
            console.error('Error inserting incomes into MySQL:', err);
            return res.status(500).json({ error: 'Failed to insert incomes into database' });
        }

        console.log('Query Result:', result);

        res.status(200).json({ message: 'Incomes submitted successfully!' });
    });
});

//GET route for fetching expenses grouped by month for user_id 1
app.get('/get-expenses-by-month', (req, res) => {
    const user_id = 1; //Hardcoded user_id for now (will be replaced once user authenticaation is done)

    //SQL query to get expenses grouped by month and year from the 'expenses' table
    const query = `
        SELECT 
            YEAR(date_spent) AS year,
            MONTH(date_spent) AS month,
            SUM(amount) AS total_amount,
            GROUP_CONCAT(description) AS descriptions
        FROM expenses
        WHERE user_id = ?
        GROUP BY YEAR(date_spent), MONTH(date_spent)
        ORDER BY year DESC, month DESC;
    `;

    db.query(query, [user_id], (err, result) => {
        if (err) {
            console.error('Error fetching expenses:', err);
            return res.status(500).json({ error: 'Failed to retrieve expenses' });
        }

        //Return expenses grouped by month
        res.json(result);
    });
});

//GET route for fetching incomes grouped by month for user_id 1
app.get('/get-incomes-by-month', (req, res) => {
    const user_id = 1; //Hardcoded user_id for now (will be replaced once user authenticaation is done)

    //SQL query to get incomes grouped by month and year from the 'Incomes' table
    const query = `
        SELECT 
            YEAR(date_received) AS year,
            MONTH(date_received) AS month,
            SUM(amount) AS total_amount,
            GROUP_CONCAT(description) AS descriptions
        FROM Incomes
        WHERE user_id = ?
        GROUP BY YEAR(date_received), MONTH(date_received)
        ORDER BY year DESC, month DESC;
    `;

    db.query(query, [user_id], (err, result) => {
        if (err) {
            console.error('Error fetching incomes:', err);
            return res.status(500).json({ error: 'Failed to retrieve incomes' });
        }

        //Return incomes grouped by month
        res.json(result);
    });
});

//POST to insert budget data into the 'budgets' table
app.post('/submit-budget', (req, res) => {
    const { user_id, total_amount, month, year } = req.body;


    if (!user_id || !total_amount || !month || !year) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    //SQL query to insert new budget record into the 'budgets' table
    const query = `
        INSERT INTO budgets (user_id, total_amount, month, year)
        VALUES (?, ?, ?, ?)
    `;

    db.query(query, [user_id, total_amount, month, year], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Failed to insert data' });
        }

        res.status(201).json({
            message: 'Budget submitted successfully',
            budget_id: result.insertId
        });
    });
});

// GET to retrieve budget data
app.get('/get-budget', (req, res) => {
    const { user_id, month, year } = req.query;

    if (!user_id || !month || !year) {
        return res.status(400).json({ error: 'User ID, Month, and Year are required' });
    }

    //SQL query to retrieve the budget data for the given user_id, month, and year
    const query = `
        SELECT * FROM budgets 
        WHERE user_id = ? AND month = ? AND year = ?
    `;

    db.query(query, [user_id, month, year], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Failed to retrieve data' });
        }

        //If no records are found
        if (results.length === 0) {
            return res.status(404).json({ error: 'No budget found for the specified criteria' });
        }

        //Return the budget data
        res.json(results);
    });
});

//GET list of expenses
app.get('/get-expenses', (req, res) => {
    const userId = req.query.user_id;
    db.query('SELECT * FROM expenses WHERE user_id = ?', [userId], (err, results) => {
        if (err) {
            return res.status(500).send('Error fetching expenses');
        }
        res.json(results);
    });
});

//GET list of incomes
app.get('/get-incomes', (req, res) => {
    const userId = req.query.user_id;
    db.query('SELECT * FROM incomes WHERE user_id = ?', [userId], (err, results) => {
        if (err) {
            return res.status(500).send('Error fetching incomes');
        }
        res.json(results);
    });
});

//GET list of budgets
app.get('/get-budgets', (req, res) => {
    const userId = req.query.user_id;
    db.query('SELECT * FROM budgets WHERE user_id = ?', [userId], (err, results) => {
        if (err) {
            return res.status(500).send('Error fetching budgets');
        }
        res.json(results);
    });
});

//GET list of expenses for user
app.get('/get-expenses-by-id', (req, res) => {
    
    const query = 'SELECT * FROM Expenses WHERE user_id = 1';

    db.query(query, (err, result) => {
        if (err) {
            console.error('Error fetching expenses:', err);
            res.status(500).send('An error occurred while fetching expenses.');
        } else {
            res.json(result);
        }
    });
});

//GET list of incomes for user
app.get('/get-incomes-by-id', (req, res) => {
    const query = 'SELECT * FROM Incomes WHERE user_id = 1';

    db.query(query, (err, result) => {
        if (err) {
            console.error('Error fetching incomes:', err);
            res.status(500).send('An error occurred while fetching incomes.');
        } else {
            res.json(result);
        }
    });
});

//GET list of expenses for user
app.get('/get-expenses-by-id/:user_id', (req, res) => {
    const userId = req.params.user_id;
    const query = 'SELECT * FROM Expenses WHERE user_id = ?';
    
    db.query(query, [userId], (err, result) => {
        if (err) {
            console.error('Error fetching expenses:', err);
            res.status(500).send('An error occurred while fetching expenses.');
        } else {
            res.json(result);
        }
    });
});

//GET list of budgets by month
app.get('/get-budgets-by-month', (req, res) => {
    const { user_id } = req.params.user_id; 

    if (!user_id) {
        return res.status(400).json({ error: 'User ID is required' });
    }

    const sql = `
        SELECT month, year, total_amount
        FROM budgets
        WHERE user_id = ? AND (month IN ('September', 'October', 'November'))
        ORDER BY FIELD(month, 'September', 'October', 'November')
    `;

    db.query(sql, [user_id], (err, results) => {
        if (err) {
            console.error('Error fetching budget data:', err);
            return res.status(500).json({ error: 'Error fetching budget data' });
        }

        res.json(results);
    });
});


// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});