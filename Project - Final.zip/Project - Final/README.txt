To use this program, go into visualstudio code, then navigate to the Server folder

enter "node server-backup.js" to start the server

You will need to construct the SQL database, since that cannot be simply thrown into guthub. However, the schemas have been included, and are in "database_schemas.txt'.
If you make a database with those tables and modify the server-backup.js to whatever your particular setup is, the project should work like normal.