Project by Abdulkarim Fattal - 200485312 Adai Yisah - 200365751 Isaac Kydd - 200449067

Section 5

The Gantt chart and Activity network are in the project presentation powerpoint slides

Sectio 6 - Conclusion and future work

in conclusion, we were able to meet most of our goals and objectives for this project. However, a couple featrues missed the deadline.

These are the ability for a user to create an account and login
A securely stored password hashing system (a result of no user login)

Other than this, we achieved our objectives, This program allows for financia, data to be tracked and stored.
It allows for quick and easy data retrieval, as well as a visual representation of that data for an easy-to-digest user-friendly experience.

It is our hope that, in the future, we will be able to implement a system to notify clients over email if they are approaching or have exceeded their budget,
as well as potentially add bank-integration to automaticallt input the user's expenses and incomes.

For now, we are satisfied with the product in it's current state as a prototype for anuser-friendly budget manager and financial planning system to help people save their hard-earned money.





The list of the meetings we had as a group, as well as brief summaries of what we discussed can be found on the "Meeting Compilation.txt" file