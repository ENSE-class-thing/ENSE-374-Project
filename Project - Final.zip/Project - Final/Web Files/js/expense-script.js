const expenseList = [];

// Performs function when the add button is clicked
document.getElementById('addItemButton').addEventListener('click', function () {
    const amount = parseFloat(document.getElementById('amount').value);
    const date = document.getElementById('date').value;
    const description = document.getElementById('description').value || 'No description'; // Default if empty, description isn't mandatory
    const category = document.getElementById('category').value;

    // If amount or date aren't there, display alert to fill those fields, return function without submitting
    if (!amount || !date) {
        alert('Please enter both amount and date.');
        return;
    }

    // Create expense object
    const expense = { amount, date, description, category };
    expenseList.push(expense);

    // Add to the list visually
    const listItem = document.createElement('li');
    listItem.classList.add('list-group-item');
    listItem.innerHTML = `${category}: $${amount} on ${date} <strong>${description}</strong> <button class="btn btn-danger btn-sm float-end delete-btn">Delete</button>`;
    document.getElementById('expenseList').appendChild(listItem);

    // Clear form fields after adding an item
    document.getElementById('amount').value = '';
    document.getElementById('date').value = '';
    document.getElementById('description').value = '';
    document.getElementById('category').value = 'rent/utilities';

    //Event listener for delete button
    listItem.querySelector('.delete-btn').addEventListener('click', function () {
        expenseList.splice(expenseList.indexOf(expense), 1);
        listItem.remove();
    });
});

// Handle submitting the expenses to the backend
document.getElementById('submitButton').addEventListener('click', function () {
    if (expenseList.length === 0) {
        alert('No expenses to submit.');
        return;
    }

    // Submit all expense data to the server
    fetch('http://localhost:3000/submit-expenses', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_id: 1, expenses: expenseList }), // Send user_id 1 and the expense list
    })
    .then(response => response.json())
    .then(data => {
        alert('Expenses submitted successfully!');
        expenseList.length = 0; // Clear the list after successful submission
        document.getElementById('expenseList').innerHTML = ''; // Clear the list on the page
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while submitting expenses.');
    });
});
