const incomeList = [];

// Performs function when the add button is clicked
document.getElementById('addItemButton').addEventListener('click', function () {
    const amount = parseFloat(document.getElementById('amount').value);
    const date = document.getElementById('date').value;
    const description = document.getElementById('description').value || 'No description'; // Default if empty, description isn't mandatory
    const source = document.getElementById('source').value;

    // If amount or date aren't there, display alert to fill those fields, return function without submitting
    if (!amount || !date) {
        alert('Please enter both amount and date.');
        return;
    }

    //Create income object
    const income = { amount, date, description, source };
    incomeList.push(income);

    // Add to the list visually
    const listItem = document.createElement('li');
    listItem.classList.add('list-group-item');
    listItem.innerHTML = `${source}: $${amount} on ${date} <strong>${description}</strong> <button class="btn btn-danger btn-sm float-end delete-btn">Delete</button>`;
    document.getElementById('incomeList').appendChild(listItem);

    // Clear form fields after adding an item
    document.getElementById('amount').value = '';
    document.getElementById('date').value = '';
    document.getElementById('description').value = '';
    document.getElementById('source').value = 'regular';

    //Event listener for delete button
    listItem.querySelector('.delete-btn').addEventListener('click', function () {
        incomeList.splice(incomeList.indexOf(income), 1);
        listItem.remove();
    });
});

// Handle submitting the incomes to the backend
document.getElementById('submitButton').addEventListener('click', function () {
    if (incomeList.length === 0) {
        alert('No incomes to submit.');
        return;
    }

    // Submit all income data to the server
    fetch('http://localhost:3000/submit-incomes', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_id: 1, incomes: incomeList }), // Send user_id 1 and the income list
    })
    .then(response => response.json())
    .then(data => {
        alert('Incomes submitted successfully!');
        incomeList.length = 0; // Clear the list after successful submission
        document.getElementById('incomeList').innerHTML = ''; // Clear the list on the page
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while submitting incomes.');
    });
});
