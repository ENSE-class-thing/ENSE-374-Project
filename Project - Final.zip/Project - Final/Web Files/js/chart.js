document.addEventListener('DOMContentLoaded', function() {
    const userId = 1; // User ID static for now, will be replaced later when user authentication added

    // Assinging integer month values to month names
    const monthNames = {
        9: 'September',
        10: 'October',
        11: 'November'
    };

    // Fetch all required data (Budgets, Incomes, and Expenses)
    Promise.all([
        fetch(`http://localhost:3000/get-budgets?user_id=${userId}`).then(response => response.json()),
        fetch('http://localhost:3000/get-incomes-by-month').then(response => response.json()),
        fetch('http://localhost:3000/get-expenses-by-month').then(response => response.json())
    ])
    .then(([budgetsData, incomesData, expensesData]) => {
        // Initialize variables to store total amounts for each month
        let septemberIncome = 0, octoberIncome = 0, novemberIncome = 0;
        let septemberExpense = 0, octoberExpense = 0, novemberExpense = 0;
        let septemberBudget = 0, octoberBudget = 0, novemberBudget = 0;
        let septemberSaved = 0, octoberSaved = 0, novemberSaved = 0;

        // Process Incomes (from get-incomes-by-month)
        incomesData.forEach(income => {
            const monthName = monthNames[income.month];
            const totalAmount = parseFloat(income.total_amount);
            if (monthName === 'September') septemberIncome += totalAmount;
            else if (monthName === 'October') octoberIncome += totalAmount;
            else if (monthName === 'November') novemberIncome += totalAmount;
        });

        // Process Expenses (from get-expenses-by-month)
        expensesData.forEach(expense => {
            const monthName = monthNames[expense.month];
            const totalAmount = parseFloat(expense.total_amount);
            if (monthName === 'September') septemberExpense += totalAmount;
            else if (monthName === 'October') octoberExpense += totalAmount;
            else if (monthName === 'November') novemberExpense += totalAmount;
        });

        // Process Budgets (from get-budgets)
        budgetsData.forEach(budget => {
            const monthName = budget.month;
            const totalAmount = parseFloat(budget.total_amount);
            if (monthName === 'September') septemberBudget = totalAmount;
            else if (monthName === 'October') octoberBudget = totalAmount;
            else if (monthName === 'November') novemberBudget = totalAmount;
        });

        // Calculate Amount Saved (Incomes - Expenses) for each month
        septemberSaved = septemberIncome - septemberExpense;
        octoberSaved = octoberIncome - octoberExpense;
        novemberSaved = novemberIncome - novemberExpense;

        //If either income or expense are empty, don't show a bar for amount saved
        if(septemberIncome == 0 || septemberExpense == 0){
            septemberSaved = 0;
        }
        if(octoberIncome == 0 || octoberExpense == 0){
            octoberSaved = 0;
        }
        if(novemberIncome == 0 || novemberExpense == 0){
            novemberSaved = 0;
        }

        // Data for chart: Monthly Incomes, Expenses, Budgets, and Amount Saved
        const months = ['September', 'October', 'November'];
        const incomes = [septemberIncome, octoberIncome, novemberIncome];
        const expenses = [septemberExpense, octoberExpense, novemberExpense];
        const budgets = [septemberBudget, octoberBudget, novemberBudget];
        const saved = [septemberSaved, octoberSaved, novemberSaved]; // Amount saved

        // Income, Expense, Budget, and Amount Saved Bar Chart (side-by-side bars for each month)
        const ctxIncomeExpense = document.getElementById('incomeExpenseChart').getContext('2d');
        new Chart(ctxIncomeExpense, {
            type: 'bar',
            data: {
                labels: months,
                datasets: [
                    {
                        label: 'Income',
                        data: incomes,
                        backgroundColor: 'rgba(75, 192, 192, 0.8)', // Light Green
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1,
                        barThickness: 20,
                        categoryPercentage: 0.4, // Adjust spacing between groups
                        barPercentage: 0.8 // Adjust the width of bars within the group
                    },
                    {
                        label: 'Expense',
                        data: expenses,
                        backgroundColor: 'rgba(255, 99, 132, 0.8)', // Light Red
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1,
                        barThickness: 20,
                        categoryPercentage: 0.4, // Adjust spacing between groups
                        barPercentage: 0.8 // Adjust the width of bars within the group
                    },
                    {
                        label: 'Budget',
                        data: budgets,
                        backgroundColor: 'rgba(54, 162, 235, 0.8)', // Light Blue
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                        barThickness: 20,
                        categoryPercentage: 0.4, // Adjust spacing between groups
                        barPercentage: 0.8 // Adjust the width of bars within the group
                    },
                    {
                        label: 'Amount Saved',
                        data: saved,
                        backgroundColor: 'rgba(153, 102, 255, 0.8)', // Light Purple
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1,
                        barThickness: 20,
                        categoryPercentage: 0.4, // Adjust spacing between groups
                        barPercentage: 0.8 // Adjust the width of bars within the group
                    }
                ]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        beginAtZero: true,
                        grid: {
                            display: false // Optional: Hide grid lines for X-axis
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            beginAtZero: true
                        }
                    }
                }
            }
        });
    })
    .catch(error => console.error('Error GETting data:', error));
});
