// Function to calculate the total budget
function calculateTotal() {
    let total = 0;
    // Loop through each input field (budget amounts)
    const categoryInputs = document.querySelectorAll('.budget-input');
    categoryInputs.forEach(input => {
        let value = parseFloat(input.value);
        if (!isNaN(value)) {
            total += value;
        }
    });

    //Sets total input box (disabled one) equal to total of every budget input
    document.getElementById('totalBudget').value = total.toFixed(2);
}

// Function to handle form submission
function handleSubmit(event) {
    event.preventDefault();
    
    // Collect the total budget amount
    const totalAmount = parseFloat(document.getElementById('totalBudget').value);
    if (isNaN(totalAmount) || totalAmount <= 0) {
        alert('Please enter a valid budget amount.');
        return;
    }

    // Collect the selected month and year
    const month = document.getElementById('monthSelect').value;
    const year = document.getElementById('yearSelect').value;

    if (!month || !year) {
        alert('Please select both month and year.');
        return;
    }

    // Static user ID (for now, it's 1, will be changed later)
    const userId = 1;


    const budgetData = {
        user_id: userId,
        total_amount: totalAmount,
        month: month,
        year: year
    };


    fetch('http://localhost:3000/submit-budget', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(budgetData),
    })
    .then(response => response.json())
    .then(data => {
        if (data.message) {
            //If successful, aalert that budget has been submitted, then clears out the fields
            alert('Budget submitted successfully!');
            document.getElementById('budgetForm').reset();
            document.getElementById('totalBudget').value = '';
        } else if (data.error) {
            alert(data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while submitting the budget.');
    });
}


document.addEventListener('DOMContentLoaded', function () {
    const budgetForm = document.getElementById('budgetForm');
    budgetForm.addEventListener('submit', handleSubmit);

    // Listen for input changes to update the total
    const categoryInputs = document.querySelectorAll('.budget-input');
    categoryInputs.forEach(input => {
        input.addEventListener('input', calculateTotal);
    });
});
