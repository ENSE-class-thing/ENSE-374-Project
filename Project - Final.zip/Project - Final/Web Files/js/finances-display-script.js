document.addEventListener("DOMContentLoaded", function () {
    // Fetch expenses data (already existing code in server js)
    fetch('http://localhost:3000/get-expenses-by-id')
        .then(response => response.json())
        .then(expenses => {
            expenses.sort((a, b) => a.expense_id - b.expense_id);
            displayData(expenses, 'expense'); // Call function to display expenses
        })
        .catch(error => {
            console.error('Error fetching expenses:', error);
            alert('An error occurred while fetching expenses.');
        });

    // Fetch incomes data (already existing code in server js)
    fetch('http://localhost:3000/get-incomes-by-id')
        .then(response => response.json())
        .then(incomes => {
            incomes.sort((a, b) => a.income_id - b.income_id);
            displayData(incomes, 'income'); // Call function to display incomes
        })
        .catch(error => {
            console.error('Error fetching incomes:', error);
            alert('An error occurred while fetching incomes.');
        });

    // Fetch budgets data (already existing code in server js)
    const userId = 1; // Will be replaced after user authentication implemented
    fetch(`http://localhost:3000/get-budgets?user_id=${userId}`)
        .then(response => response.json())
        .then(budgets => {
            budgets.sort((a, b) => a.budget_id - b.budget_id);
            displayBudgets(budgets); // Call function to display budgets
        })
        .catch(error => {
            console.error('Error fetching budgets:', error);
            alert('An error occurred while fetching budgets.');
        });
});

// Function to display expenses or incomes in a table
function displayData(data, type) {
    const tableBody = document.getElementById('income-expense-table').getElementsByTagName('tbody')[0];

    data.forEach(item => {
        const row = document.createElement('tr');

        // Extract date and details from the item
        const date = new Date(item.date_spent || item.date_received); // Handle both expenses and incomes
        const day = date.getDate();
        const month = date.getMonth() + 1;
        const year = date.getFullYear();
        const totalAmount = item.amount;
        const descriptions = item.description || item.source;
        const typeLabel = type.charAt(0).toUpperCase() + type.slice(1);

        row.innerHTML = `
            <td>${day}</td>
            <td>${month}</td>
            <td>${year}</td>
            <td>$${totalAmount}</td>
            <td>${descriptions}</td>
            <td>${typeLabel}</td>
        `;

        //Adds items to a table until all items are added
        tableBody.appendChild(row);
    });
}

// Function to display budgets data in seperate table
function displayBudgets(budgets) {
    const tableBody = document.getElementById('budgets-table').getElementsByTagName('tbody')[0];

    budgets.forEach(budget => {
        const row = document.createElement('tr');

        const month = budget.month;
        const year = budget.year;
        const totalAmount = budget.total_amount;

        row.innerHTML = `
            <td>${month}</td>
            <td>${year}</td>
            <td>$${totalAmount}</td>
        `;

        tableBody.appendChild(row);
    });
}
